
function PlayerRoom(){
    return (
        <h1>Waiting host to start the game</h1>
    )
}

export default PlayerRoom
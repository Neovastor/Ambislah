// import {gql} from '@apollo/client'
export {
    ADD_REPORT,
    DELETE_REPORT,
    GET_ALL_REPORTS,
    GET_REPORT,
    SEARCH_REPORT,
} from './reportQueries'

export {
    REGISTER,
    LOGIN
} from './userQueries'


export {
    GET_ALL_QUIZ,
    CREATED_QUIZZES,
    ADD_QUIZZES,
    DELETE_QUIZZEZ,
    UPDATE_QUIZZES
} from './quizQueries'
